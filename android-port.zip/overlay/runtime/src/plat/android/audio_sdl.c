/* Host audio backend for Android (replaces audio.c, which drives Windows waveOut).
 *
 * Same design as audio.c: a 44.1 kHz stereo mixing ring. Each guest channel keeps its own write
 * cursor over a shared int32 accumulator, so simultaneous channels sum instead of interleaving.
 * The difference is the drain: SDL3 calls back from the platform's audio thread (AAudio/OpenSL)
 * whenever the device wants more, and the callback pulls frames out of the ring (clamped to s16;
 * silence if the game has not written ahead). Public API is identical to audio.c:
 *   sr_audio_init / sr_audio_push / sr_audio_block_frames / sr_audio_queued, g_audio_frames. */
#include <SDL3/SDL.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

#define RING_FRAMES  (1 << 16)            /* 64k frames ~ 1.5 s of headroom */
#define RING_MASK    (RING_FRAMES - 1)
#define BLOCK_FRAMES 1024                 /* the unit the drain works in (~23 ms) */

static int32_t  s_accL[RING_FRAMES], s_accR[RING_FRAMES];
static uint64_t s_play = 0;               /* drain (read) cursor, frames */
static uint64_t s_chw[8];                 /* per-channel write cursors, frames */
static SDL_Mutex *s_lock = NULL;
static SDL_AudioStream *s_stream = NULL;
static int s_inited = 0, s_ok = 0;

unsigned long g_audio_frames[8];          /* frames submitted per channel (SR_SCHEDSTAT) */

static int16_t clamp16(int32_t v) { return v < -32768 ? -32768 : v > 32767 ? 32767 : (int16_t)v; }

static void SDLCALL audio_cb(void *ud, SDL_AudioStream *st, int additional, int total) {
    (void)ud; (void)total;
    static int16_t blk[BLOCK_FRAMES * 2];
    int need = additional / 4;            /* frames the device wants right now */
    while (need > 0) {
        int n = need < BLOCK_FRAMES ? need : BLOCK_FRAMES;
        SDL_LockMutex(s_lock);
        for (int i = 0; i < n; i++) {
            uint32_t idx = (uint32_t)((s_play + (uint64_t)i) & RING_MASK);
            blk[i * 2 + 0] = clamp16(s_accL[idx]);
            blk[i * 2 + 1] = clamp16(s_accR[idx]);
            s_accL[idx] = s_accR[idx] = 0;
        }
        s_play += (uint64_t)n;
        SDL_UnlockMutex(s_lock);
        SDL_PutAudioStreamData(st, blk, n * 4);
        need -= n;
    }
}

int sr_audio_init(void) {
    if (s_inited) return s_ok;
    s_inited = 1;
    if (getenv("SR_NOAUDIO")) return s_ok = 0;
    s_lock = SDL_CreateMutex();
    if (!s_lock) return s_ok = 0;
    if (!SDL_InitSubSystem(SDL_INIT_AUDIO)) {
        fprintf(stderr, "audio: SDL audio init failed: %s (silent run)\n", SDL_GetError());
        return s_ok = 0;
    }
    SDL_SetHint(SDL_HINT_AUDIO_DEVICE_SAMPLE_FRAMES, "1024");
    SDL_AudioSpec spec; SDL_zero(spec);
    spec.format = SDL_AUDIO_S16; spec.channels = 2; spec.freq = 44100;
    s_stream = SDL_OpenAudioDeviceStream(SDL_AUDIO_DEVICE_DEFAULT_PLAYBACK, &spec, audio_cb, NULL);
    if (!s_stream) {
        fprintf(stderr, "audio: cannot open the output device: %s (silent run)\n", SDL_GetError());
        return s_ok = 0;
    }
    SDL_ResumeAudioStreamDevice(s_stream);
    fprintf(stderr, "audio: SDL3 44100 Hz stereo open\n");
    return s_ok = 1;
}

/* Mix nframes of interleaved stereo s16 into the channel's slice of the ring.
 * volL/volR are 0..0x8000 (PSP panned-output volumes). */
void sr_audio_push(int ch, const int16_t *lr, int nframes, int volL, int volR) {
    if (!sr_audio_init() || nframes <= 0) return;
    if (ch < 0) ch = 0;
    ch &= 7;
    g_audio_frames[ch] += (unsigned long)nframes;
    SDL_LockMutex(s_lock);
    uint64_t w = s_chw[ch];
    if (w < s_play) w = s_play;                            /* channel fell behind: snap to now */
    if (w + (uint64_t)nframes > s_play + RING_FRAMES)      /* too far ahead: clamp (drop tail) */
        nframes = (int)(s_play + RING_FRAMES - w);
    for (int i = 0; i < nframes; i++) {
        uint32_t idx = (uint32_t)((w + (uint64_t)i) & RING_MASK);
        s_accL[idx] += ((int32_t)lr[i * 2 + 0] * volL) >> 15;
        s_accR[idx] += ((int32_t)lr[i * 2 + 1] * volR) >> 15;
    }
    s_chw[ch] = w + (uint64_t)(nframes > 0 ? nframes : 0);
    SDL_UnlockMutex(s_lock);
}

/* A channel must stay at least this far ahead of the playhead or a block is drained half-written. */
int sr_audio_block_frames(void) { return BLOCK_FRAMES; }

/* Frames this channel has queued ahead of the playhead (-1: no host audio). The blocking
 * output calls pace against this, like real hardware. */
int sr_audio_queued(int ch) {
    if (!s_ok) return -1;
    ch &= 7;
    SDL_LockMutex(s_lock);
    uint64_t w = s_chw[ch], p = s_play;
    SDL_UnlockMutex(s_lock);
    return w > p ? (int)(w - p) : 0;
}
