/* Replaces gpu_sdl3vk/texpack_ppsspp.c on Android: PPSSPP-style HD texture packs. That file
 * needs x86 SSE2 and the xxhash header; texture packs are optional, so for now "no pack". */
#include "recomp.h"
#include "ge_shared.h"
int ppx_init(const char *texdir) { (void)texdir; return 0; }
const char *ppx_lookup(const GeState *ge) { (void)ge; return 0; }
