#include <windows.h>
#include <assert.h>
#include <dlfcn.h>

static LPVOID f_main, f_a, f_b;
static int trace[64], nt;
static void CALLBACK fa(void *p) {
    for (int i = 0; i < 3; i++) { trace[nt++] = 100 + i; SwitchToFiber(f_b); }
    trace[nt++] = 199; SwitchToFiber(f_main);
}
static int deep(int n) { volatile char pad[2048]; pad[0] = 1; return n ? deep(n - 1) + pad[0] : 0; }
static void CALLBACK fb(void *p) {
    for (int i = 0; i < 3; i++) { trace[nt++] = 200 + i; trace[nt++] = deep(5000); SwitchToFiber(f_a); }
    for (;;) SwitchToFiber(f_main);
}
static LONG WINAPI filt(EXCEPTION_POINTERS *ep) {
    fprintf(stderr, "FILTER: code=%08x addr=%p info1=%p\n", (unsigned)ep->ExceptionRecord->ExceptionCode,
            ep->ExceptionRecord->ExceptionAddress, (void *)ep->ExceptionRecord->ExceptionInformation[1]);
    return EXCEPTION_CONTINUE_SEARCH;
}
int main(int argc, char **argv) {
    if (argc > 1 && !strcmp(argv[1], "crash")) { SetUnhandledExceptionFilter(filt); *(volatile int *)0x1234 = 1; return 0; }
    /* fibers: main -> a -> b -> a -> b ... with a 64 MB stack and 5000-deep recursion (10 MB) */
    f_main = ConvertThreadToFiber(NULL);
    f_a = CreateFiberEx(256 * 1024, 64u << 20, 0, fa, NULL);
    f_b = CreateFiberEx(256 * 1024, 64u << 20, 0, fb, NULL);
    SwitchToFiber(f_a);
    int expect[] = {100, 200, 5000, 101, 201, 5000, 102, 202, 5000, 199};
    for (int i = 0; i < nt; i++) fprintf(stderr, "%d ", trace[i]);
    fprintf(stderr, "\n");
    assert(nt == 10 && !memcmp(trace, expect, sizeof expect));
    DeleteFiber(f_a); DeleteFiber(f_b);
    puts("fibers ok");
    /* switch speed */
    LARGE_INTEGER q0, q1; f_a = CreateFiberEx(0, 1 << 20, 0, fb, NULL);
    printf("QPC freq ok\n"); QueryPerformanceCounter(&q0); QueryPerformanceCounter(&q1); assert(q1.QuadPart >= q0.QuadPart);
    /* files: backslash paths, find with wildcard, attributes, move/replace */
    system("rm -rf /tmp/shimt && mkdir -p /tmp/shimt");
    assert(CreateDirectoryA("/tmp/shimt\\PSP", NULL));
    assert(!CreateDirectoryA("/tmp/shimt\\PSP", NULL) && GetLastError() == ERROR_ALREADY_EXISTS);
    FILE *f = fopen("/tmp/shimt\\PSP\\Game.ISO", "wb"); assert(f); fputs("x", f); fclose(f);
    f = fopen("/tmp/shimt/PSP/other.txt", "wb"); fputs("y", f); fclose(f);
    WIN32_FIND_DATAA fd; HANDLE h = FindFirstFileA("/tmp/shimt\\PSP\\*.iso", &fd);
    assert(h != INVALID_HANDLE_VALUE); printf("found %s attr=%x size=%u\n", fd.cFileName, fd.dwFileAttributes, fd.nFileSizeLow);
    assert(!strcmp(fd.cFileName, "Game.ISO") && !FindNextFileA(h, &fd)); FindClose(h);
    int n = 0; h = FindFirstFileA("/tmp/shimt\\PSP\\*", &fd); do n++; while (FindNextFileA(h, &fd)); FindClose(h);
    printf("entries in dir (incl . ..) = %d\n", n); assert(n == 4);
    assert(FindFirstFileA("/tmp/shimt/nope/*", &fd) == INVALID_HANDLE_VALUE);
    assert(GetFileAttributesA("/tmp/shimt\\PSP") == FILE_ATTRIBUTE_DIRECTORY && GetFileAttributesA("/tmp/shimt/zzz") == INVALID_FILE_ATTRIBUTES);
    WIN32_FILE_ATTRIBUTE_DATA fa2; assert(GetFileAttributesExA("/tmp/shimt\\PSP\\other.txt", GetFileExInfoStandard, &fa2) && fa2.nFileSizeLow == 1);
    assert(MoveFileExA("/tmp/shimt\\PSP\\other.txt", "/tmp/shimt\\PSP\\Game.ISO", MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH));
    assert(CopyFileA("/tmp/shimt/PSP/Game.ISO", "/tmp/shimt/copy.bin", FALSE) && DeleteFileA("/tmp/shimt/copy.bin"));
    assert(rename("/tmp/shimt\\PSP", "/tmp/shimt\\PSP2") == 0 && GetFileAttributesA("/tmp/shimt/PSP2") == FILE_ATTRIBUTE_DIRECTORY);
    /* time */
    SYSTEMTIME st; FILETIME ft, lt; ft.dwHighDateTime = 0x01D9A7BD; ft.dwLowDateTime = 0x0; /* some 2023 date */
    assert(FileTimeToSystemTime(&ft, &st)); printf("systemtime %04u-%02u-%02u\n", st.wYear, st.wMonth, st.wDay); assert(st.wYear >= 2020);
    FileTimeToLocalFileTime(&ft, &lt); GetLocalTime(&st); GetSystemTimeAsFileTime(&ft);
    /* dlopen mapping: game.dll -> libgame.so in SR_HOME */
    setenv("SR_HOME", "/tmp/shimt", 1);
    system("cd /tmp/shimt && printf 'int sr_game_attach(void*a,int v){return v+1;}' > g.c && gcc -shared -fPIC -o libgame.so g.c");
    HMODULE m = LoadLibraryA("game.dll"); assert(m);
    int (*att)(void *, int) = (int (*)(void *, int))GetProcAddress(m, "sr_game_attach"); assert(att && att(0, 41) == 42);
    assert(!LoadLibraryA("nothere.dll"));
    char exe[MAX_PATH]; GetModuleFileNameA(NULL, exe, sizeof exe); printf("exe=%s\n", exe);
    puts("ALL OK");
    return 0;
}
