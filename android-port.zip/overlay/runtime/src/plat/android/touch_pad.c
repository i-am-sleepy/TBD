/* On-screen controls -> the game. The Java overlay (TouchOverlay.java) reports which buttons
 * are held and where the stick is; this turns that into a virtual SDL gamepad. sdl3vk.c already
 * opens any gamepad that appears (SDL_EVENT_GAMEPAD_ADDED), so it needs no changes. */
#include <jni.h>
#include <SDL3/SDL.h>

static SDL_Joystick *s_vj;
static int s_failed;

static void ensure(void) {
    if (s_vj || s_failed || !SDL_WasInit(SDL_INIT_JOYSTICK)) return;   /* SDL not up yet: try next touch */
    SDL_VirtualJoystickDesc d;
    SDL_INIT_INTERFACE(&d);
    d.type = SDL_JOYSTICK_TYPE_GAMEPAD;
    d.naxes = SDL_GAMEPAD_AXIS_COUNT;
    d.nbuttons = SDL_GAMEPAD_BUTTON_COUNT;
    d.name = "On-screen controls";
    SDL_JoystickID id = SDL_AttachVirtualJoystick(&d);
    if (!id) { s_failed = 1; return; }
    s_vj = SDL_OpenJoystick(id);
    if (!s_vj) s_failed = 1;
}

/* bit i of `buttons`: 0 cross,1 circle,2 square,3 triangle,4 select,5 start,6 L,7 R,
 * 8 up,9 down,10 left,11 right. lx/ly: -32768..32767. */
JNIEXPORT void JNICALL Java_com_the3rdbirthday_recomp_TouchOverlay_nativePad(JNIEnv *env, jclass cls,
                                                                         jint buttons, jint lx, jint ly) {
    (void)env; (void)cls;
    static const int map[12] = {
        SDL_GAMEPAD_BUTTON_SOUTH, SDL_GAMEPAD_BUTTON_EAST, SDL_GAMEPAD_BUTTON_WEST, SDL_GAMEPAD_BUTTON_NORTH,
        SDL_GAMEPAD_BUTTON_BACK, SDL_GAMEPAD_BUTTON_START,
        SDL_GAMEPAD_BUTTON_LEFT_SHOULDER, SDL_GAMEPAD_BUTTON_RIGHT_SHOULDER,
        SDL_GAMEPAD_BUTTON_DPAD_UP, SDL_GAMEPAD_BUTTON_DPAD_DOWN,
        SDL_GAMEPAD_BUTTON_DPAD_LEFT, SDL_GAMEPAD_BUTTON_DPAD_RIGHT };
    ensure();
    if (!s_vj) return;
    for (int i = 0; i < 12; i++) SDL_SetJoystickVirtualButton(s_vj, map[i], ((buttons >> i) & 1) != 0);
    SDL_SetJoystickVirtualAxis(s_vj, SDL_GAMEPAD_AXIS_LEFTX, (Sint16)lx);
    SDL_SetJoystickVirtualAxis(s_vj, SDL_GAMEPAD_AXIS_LEFTY, (Sint16)ly);
}
