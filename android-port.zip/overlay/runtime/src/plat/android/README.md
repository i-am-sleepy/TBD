Android (bionic/arm64) platform layer. See /android/README.md for the overview.

include/windows.h, shim.c   Win32 subset implemented on POSIX. `-I` puts include/ first, so
                            `#include <windows.h>` in upstream files finds it.
include/sr_msvcrt.h         _stricmp, _fseeki64 ...; force-included into every runtime C file.
audio_sdl.c                 replaces audio.c (waveOut) with an SDL3 audio stream.
h264_stub.c                 replaces h264_mf.c: no movie decoder yet (same answer as SR_NOH264=1).
osk_stub.c ctrl_stub.c update_stub.c texpack_stub.c   replace osk_win.c, ctrl_server.c, update.c,
                            texpack_ppsspp.c.
touch_pad.c                 JNI: touch overlay -> SDL virtual gamepad.
test/test_shim.c            Linux test of the shim:
                              gcc -Iinclude shim.c test/test_shim.c -o t -ldl && ./t
