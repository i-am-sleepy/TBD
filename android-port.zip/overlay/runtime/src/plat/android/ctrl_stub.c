/* Replaces ctrl_server.c (a Winsock test channel used by the author's automated tests). */
#include <stdint.h>

/* ctrl_server.c also owned this flag (the "drawlog" test hook); ge.c and gui.c read it. */
volatile int g_drawlog_on = 0;

uint32_t ctrlsrv_take_presses(void) { return 0; }
void ctrlsrv_apply(uint32_t *btn, uint8_t *lx, uint8_t *ly) { (void)btn; (void)lx; (void)ly; }
void ctrlsrv_start(void) {}
