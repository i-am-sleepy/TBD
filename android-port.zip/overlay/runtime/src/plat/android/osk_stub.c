/* Replaces osk_win.c (a Win32 dialog box that answers the game's on-screen-keyboard requests).
 * Returning 0 = "cancelled": the game keeps the text it already has. (Planned: Android's
 * keyboard through SDL text input.) The prototype matches hle.c's (wchar_t, not WCHAR). */
#include <wchar.h>
int sr_osk_input(const wchar_t *desc, const wchar_t *initial, wchar_t *out, int cap) {
    (void)desc; (void)initial; (void)out; (void)cap;
    return 0;
}
