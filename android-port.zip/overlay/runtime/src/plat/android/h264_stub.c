/* Replaces h264_mf.c (H.264 through Windows Media Foundation) for the first Android builds.
 * sr_h264_create() == -1 is the same "no decoder" answer the Windows build gives with
 * SR_NOH264=1, so mpeg.c already copes: movies play no picture. A real decoder (OpenH264 or
 * Android MediaCodec behind this same API, reusing h264_mf.c's program-stream demuxer) is the
 * next milestone. */
#include <stdint.h>
int  sr_h264_create(void) { return -1; }
void sr_h264_destroy(int id) { (void)id; }
void sr_h264_feed(int id, const uint8_t *data, uint32_t len) { (void)id; (void)data; (void)len; }
uint32_t sr_h264_pending_bytes(int id) { (void)id; return 0; }
int  sr_h264_frame(int id, int eos, uint8_t *dst, int frameWidth, int pixelMode) {
    (void)id; (void)eos; (void)dst; (void)frameWidth; (void)pixelMode; return -1;
}
