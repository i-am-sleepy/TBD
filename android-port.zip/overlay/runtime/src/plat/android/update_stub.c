/* Replaces update.c (a WinHTTP "newer version available" check). On Android you update by
 * installing a newer APK, so there is nothing to check at runtime. */
#ifndef SR_VERSION
#define SR_VERSION "android-dev"
#endif
const char *sr_version(void) { return SR_VERSION; }
const char *sr_update_available(void) { return 0; }
void sr_update_check_start(void) {}
