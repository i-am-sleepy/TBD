/* Implementation of the Win32 compatibility shim (see include/windows.h). POSIX only. */
#define _GNU_SOURCE
#include <windows.h>
/* windows.h wraps these libc calls to normalise '\' paths; here we need the real ones. */
#undef fopen
#undef remove
#undef rename
#undef _mkdir

#include <ctype.h>
#include <dirent.h>
#include <dlfcn.h>
#include <fcntl.h>
#include <limits.h>
#include <signal.h>
#include <ucontext.h>
#include <sys/mman.h>
#ifdef __ANDROID__
#include <android/log.h>
#endif

/* ---- errors ------------------------------------------------------------------------------ */
static __thread DWORD s_err;
DWORD GetLastError(void) { return s_err; }
static void set_err_errno(void) {
    switch (errno) {
        case EEXIST: s_err = ERROR_ALREADY_EXISTS; break;
        case ENOENT: s_err = ERROR_FILE_NOT_FOUND; break;
        case ENOTDIR: s_err = ERROR_PATH_NOT_FOUND; break;
        case ENOTEMPTY: s_err = ERROR_DIR_NOT_EMPTY; break;
        default: s_err = ERROR_ACCESS_DENIED; break;
    }
}

/* ---- path normalisation: Windows code builds paths with '\' ------------------------------- */
static const char *norm(char *out, size_t cap, const char *in) {
    size_t i = 0;
    if (!in) { out[0] = 0; return out; }
    for (; in[i] && i + 1 < cap; i++) out[i] = (in[i] == '\\') ? '/' : in[i];
    out[i] = 0;
    return out;
}
#define NORM(var, src) char var[PATH_MAX]; norm(var, sizeof(var), (src))

FILE *sr_fopen(const char *path, const char *mode) { NORM(p, path); return fopen(p, mode); }
int sr_remove(const char *path) { NORM(p, path); return remove(p); }
int sr_rename(const char *from, const char *to) { NORM(a, from); NORM(b, to); return rename(a, b); }
int sr_mkdir(const char *path) { NORM(p, path); return mkdir(p, 0775); }

/* ---- timing ------------------------------------------------------------------------------- */
static uint64_t mono_ns(void) {
    struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)ts.tv_sec * 1000000000ull + (uint64_t)ts.tv_nsec;
}
BOOL QueryPerformanceFrequency(LARGE_INTEGER *f) { f->QuadPart = 1000000000ll; return TRUE; }
BOOL QueryPerformanceCounter(LARGE_INTEGER *c) {
    static uint64_t base;
    if (!base) base = mono_ns() - 1000000000ull;      /* first call reads ~1 s: never 0 */
    c->QuadPart = (LONGLONG)(mono_ns() - base);
    return TRUE;
}
void Sleep(DWORD ms) {
    struct timespec ts = { ms / 1000, (long)(ms % 1000) * 1000000L };
    while (nanosleep(&ts, &ts) != 0 && errno == EINTR) {}
}
ULONGLONG GetTickCount64(void) { return mono_ns() / 1000000ull; }

#define FT_EPOCH_DIFF 11644473600ull      /* seconds between 1601-01-01 and 1970-01-01 */
static uint64_t ft_get(const FILETIME *f) { return ((uint64_t)f->dwHighDateTime << 32) | f->dwLowDateTime; }
static void ft_set(FILETIME *f, uint64_t v) { f->dwLowDateTime = (DWORD)v; f->dwHighDateTime = (DWORD)(v >> 32); }
static uint64_t ft_from_ts(const struct timespec *t) {
    return ((uint64_t)t->tv_sec + FT_EPOCH_DIFF) * 10000000ull + (uint64_t)(t->tv_nsec / 100);
}
void GetSystemTimeAsFileTime(FILETIME *ft) {
    struct timespec ts; clock_gettime(CLOCK_REALTIME, &ts); ft_set(ft, ft_from_ts(&ts));
}
static void tm_to_st(const struct tm *tm, unsigned ms, SYSTEMTIME *st) {
    st->wYear = (WORD)(tm->tm_year + 1900); st->wMonth = (WORD)(tm->tm_mon + 1);
    st->wDayOfWeek = (WORD)tm->tm_wday;     st->wDay = (WORD)tm->tm_mday;
    st->wHour = (WORD)tm->tm_hour;          st->wMinute = (WORD)tm->tm_min;
    st->wSecond = (WORD)tm->tm_sec;         st->wMilliseconds = (WORD)ms;
}
void GetLocalTime(SYSTEMTIME *st) {
    struct timespec ts; clock_gettime(CLOCK_REALTIME, &ts);
    struct tm tm; time_t t = ts.tv_sec; localtime_r(&t, &tm);
    tm_to_st(&tm, (unsigned)(ts.tv_nsec / 1000000), st);
}
BOOL FileTimeToSystemTime(const FILETIME *ft, SYSTEMTIME *st) {
    uint64_t v = ft_get(ft);
    if (v < FT_EPOCH_DIFF * 10000000ull) return FALSE;
    time_t t = (time_t)(v / 10000000ull - FT_EPOCH_DIFF);
    struct tm tm; if (!gmtime_r(&t, &tm)) return FALSE;
    tm_to_st(&tm, (unsigned)((v % 10000000ull) / 10000ull), st);
    return TRUE;
}
BOOL FileTimeToLocalFileTime(const FILETIME *ft, FILETIME *local) {
    uint64_t v = ft_get(ft);
    long off = 0;
    if (v >= FT_EPOCH_DIFF * 10000000ull) {
        time_t t = (time_t)(v / 10000000ull - FT_EPOCH_DIFF);
        struct tm tm; if (localtime_r(&t, &tm)) off = tm.tm_gmtoff;
    }
    ft_set(local, v + (uint64_t)((int64_t)off * 10000000ll));
    return TRUE;
}
LONG CompareFileTime(const FILETIME *a, const FILETIME *b) {
    uint64_t x = ft_get(a), y = ft_get(b);
    return x < y ? -1 : x > y ? 1 : 0;
}

/* ---- files ------------------------------------------------------------------------------ */
static DWORD attrs_from_stat(const struct stat *st) {
    DWORD a = S_ISDIR(st->st_mode) ? FILE_ATTRIBUTE_DIRECTORY : FILE_ATTRIBUTE_NORMAL;
    if (!(st->st_mode & S_IWUSR)) a |= FILE_ATTRIBUTE_READONLY;
    return a;
}
static void fill_times(const struct stat *st, FILETIME *c, FILETIME *a, FILETIME *w) {
    ft_set(c, ft_from_ts(&st->st_ctim));
    ft_set(a, ft_from_ts(&st->st_atim));
    ft_set(w, ft_from_ts(&st->st_mtim));
}

BOOL CreateDirectoryA(const char *path, void *sec) {
    (void)sec; NORM(p, path);
    if (mkdir(p, 0775) == 0) return TRUE;
    set_err_errno(); return FALSE;
}
BOOL RemoveDirectoryA(const char *path) { NORM(p, path); if (rmdir(p) == 0) return TRUE; set_err_errno(); return FALSE; }
BOOL DeleteFileA(const char *path) { NORM(p, path); if (unlink(p) == 0) return TRUE; set_err_errno(); return FALSE; }
BOOL MoveFileExA(const char *from, const char *to, DWORD flags) {
    NORM(a, from); NORM(b, to);
    if (!(flags & MOVEFILE_REPLACE_EXISTING) && access(b, F_OK) == 0) { s_err = ERROR_ALREADY_EXISTS; return FALSE; }
    if (rename(a, b) == 0) return TRUE;
    set_err_errno(); return FALSE;
}
BOOL CopyFileA(const char *from, const char *to, BOOL failIfExists) {
    NORM(a, from); NORM(b, to);
    if (failIfExists && access(b, F_OK) == 0) { s_err = ERROR_ALREADY_EXISTS; return FALSE; }
    FILE *in = fopen(a, "rb"); if (!in) { set_err_errno(); return FALSE; }
    FILE *out = fopen(b, "wb"); if (!out) { set_err_errno(); fclose(in); return FALSE; }
    char buf[65536]; size_t n; int ok = 1;
    while ((n = fread(buf, 1, sizeof buf, in)) > 0) if (fwrite(buf, 1, n, out) != n) { ok = 0; break; }
    fclose(in); if (fclose(out) != 0) ok = 0;
    return ok;
}
DWORD GetFileAttributesA(const char *path) {
    NORM(p, path); struct stat st;
    if (stat(p, &st) != 0) { set_err_errno(); return INVALID_FILE_ATTRIBUTES; }
    return attrs_from_stat(&st);
}
BOOL GetFileAttributesExA(const char *path, GET_FILEEX_INFO_LEVELS level, void *data) {
    (void)level; NORM(p, path); struct stat st;
    if (stat(p, &st) != 0) { set_err_errno(); return FALSE; }
    WIN32_FILE_ATTRIBUTE_DATA *d = (WIN32_FILE_ATTRIBUTE_DATA *)data;
    d->dwFileAttributes = attrs_from_stat(&st);
    fill_times(&st, &d->ftCreationTime, &d->ftLastAccessTime, &d->ftLastWriteTime);
    d->nFileSizeHigh = (DWORD)((uint64_t)st.st_size >> 32); d->nFileSizeLow = (DWORD)st.st_size;
    return TRUE;
}
BOOL SetCurrentDirectoryA(const char *dir) { NORM(p, dir); return chdir(p) == 0; }

/* FindFirstFileA / FindNextFileA: "dir/pattern" with * and ? wildcards, case-insensitive. */
typedef struct { DIR *d; char dir[PATH_MAX]; char pat[256]; } FindCtx;
static int wild(const char *p, const char *s) {
    for (; *p; p++, s++) {
        if (*p == '*') {
            while (p[1] == '*') p++;
            if (!p[1]) return 1;
            for (; *s; s++) if (wild(p + 1, s)) return 1;
            return wild(p + 1, s);
        }
        if (!*s) return 0;
        if (*p != '?' && tolower((unsigned char)*p) != tolower((unsigned char)*s)) return 0;
    }
    return *s == 0;
}
static int find_next(FindCtx *c, WIN32_FIND_DATAA *fd) {
    struct dirent *e;
    while ((e = readdir(c->d)) != NULL) {
        if (!wild(c->pat, e->d_name)) continue;
        struct stat st; char full[PATH_MAX + 300];
        snprintf(full, sizeof full, "%s/%s", c->dir, e->d_name);
        memset(fd, 0, sizeof *fd);
        snprintf(fd->cFileName, sizeof fd->cFileName, "%s", e->d_name);
        if (stat(full, &st) == 0) {
            fd->dwFileAttributes = attrs_from_stat(&st);
            fill_times(&st, &fd->ftCreationTime, &fd->ftLastAccessTime, &fd->ftLastWriteTime);
            fd->nFileSizeHigh = (DWORD)((uint64_t)st.st_size >> 32); fd->nFileSizeLow = (DWORD)st.st_size;
        } else fd->dwFileAttributes = FILE_ATTRIBUTE_NORMAL;
        return 1;
    }
    return 0;
}
HANDLE FindFirstFileA(const char *pattern, WIN32_FIND_DATAA *fd) {
    NORM(p, pattern);
    FindCtx *c = (FindCtx *)calloc(1, sizeof *c);
    if (!c) return INVALID_HANDLE_VALUE;
    char *slash = strrchr(p, '/');
    if (slash) { *slash = 0; snprintf(c->dir, sizeof c->dir, "%s", slash == p ? "/" : p); snprintf(c->pat, sizeof c->pat, "%.255s", slash + 1); }
    else { snprintf(c->dir, sizeof c->dir, "."); snprintf(c->pat, sizeof c->pat, "%.255s", p); }
    if (!strcmp(c->pat, "*.*")) strcpy(c->pat, "*");
    c->d = opendir(c->dir);
    if (!c->d) { set_err_errno(); free(c); return INVALID_HANDLE_VALUE; }
    if (!find_next(c, fd)) { s_err = ERROR_FILE_NOT_FOUND; closedir(c->d); free(c); return INVALID_HANDLE_VALUE; }
    return c;
}
BOOL FindNextFileA(HANDLE h, WIN32_FIND_DATAA *fd) { return (h && h != INVALID_HANDLE_VALUE) ? find_next((FindCtx *)h, fd) : FALSE; }
BOOL FindClose(HANDLE h) {
    if (!h || h == INVALID_HANDLE_VALUE) return FALSE;
    FindCtx *c = (FindCtx *)h; closedir(c->d); free(c); return TRUE;
}

/* The app's private folder is where everything lives (saves, settings, game library). The
 * Java side exports it as SR_HOME; the process working directory is changed to it at start. */
DWORD GetModuleFileNameA(HMODULE m, char *buf, DWORD size) {
    (void)m;
    const char *home = getenv("SR_HOME");
    char cwd[PATH_MAX];
    if (!home || !*home) home = getcwd(cwd, sizeof cwd) ? cwd : ".";
    int n = snprintf(buf, size, "%s/ULUS10567.exe", home);
    return n < 0 ? 0 : (DWORD)(n < (int)size ? n : (int)size - 1);
}

/* ---- dynamic libraries ------------------------------------------------------------------- */
/* "game.dll" (or ".../game.dll") loads lib<name>.so from SR_HOME / the same folder. */
HMODULE LoadLibraryA(const char *name) {
    char path[PATH_MAX];
    size_t n = strlen(name);
    if (n > 4 && !strcasecmp(name + n - 4, ".dll")) {
        const char *base = strrchr(name, '/'); base = base ? base + 1 : name;
        const char *home = getenv("SR_HOME");
        if (strchr(name, '/')) snprintf(path, sizeof path, "%.*s/lib%.*s.so", (int)(base - name - 1), name, (int)strlen(base) - 4, base);
        else snprintf(path, sizeof path, "%s/lib%.*s.so", home && *home ? home : ".", (int)strlen(base) - 4, base);
    } else snprintf(path, sizeof path, "%s", name);
    void *h = dlopen(path, RTLD_NOW | RTLD_LOCAL);
    if (!h) fprintf(stderr, "LoadLibrary(%s): %s\n", path, dlerror());
    return h;
}
void *GetProcAddress(HMODULE m, const char *name) { return m ? dlsym(m, name) : NULL; }
BOOL FreeLibrary(HMODULE m) { return m && dlclose(m) == 0; }

/* ---- message boxes / console ------------------------------------------------------------- */
int MessageBoxA(HWND parent, const char *text, const char *caption, UINT type) {
    (void)parent; (void)type;
    fprintf(stderr, "[%s] %s\n", caption ? caption : "message", text ? text : "");
#ifdef __ANDROID__
    __android_log_print(ANDROID_LOG_ERROR, "The3rdBirthday", "[%s] %s", caption ? caption : "message", text ? text : "");
#endif
    return 1;
}
DWORD GetConsoleProcessList(DWORD *pids, DWORD n) { (void)pids; (void)n; return 0; }
HWND GetConsoleWindow(void) { return NULL; }
BOOL ShowWindow(HWND w, int cmd) { (void)w; (void)cmd; return FALSE; }

/* ---- crash reporting ----------------------------------------------------------------------- */
static LPTOP_LEVEL_EXCEPTION_FILTER s_filter;
static void crash_handler(int sig, siginfo_t *si, void *uc) {
    EXCEPTION_RECORD er; EXCEPTION_POINTERS ep = { &er, uc };
    memset(&er, 0, sizeof er);
    er.ExceptionCode = (sig == SIGSEGV || sig == SIGBUS) ? EXCEPTION_ACCESS_VIOLATION
                     : sig == SIGILL ? EXCEPTION_ILLEGAL_INSTRUCTION : 0xC0000000u | (DWORD)sig;
    ucontext_t *u = (ucontext_t *)uc; (void)u;
#if defined(__aarch64__)
    er.ExceptionAddress = (void *)u->uc_mcontext.pc;
#elif defined(__x86_64__)
    er.ExceptionAddress = (void *)u->uc_mcontext.gregs[REG_RIP];
    er.ExceptionInformation[0] = (u->uc_mcontext.gregs[REG_ERR] & 2) ? 1 : 0;   /* 1 = write */
#endif
    er.NumberParameters = 2;
    er.ExceptionInformation[1] = (ULONG_PTR)si->si_addr;
    if (s_filter) s_filter(&ep);
    /* SA_RESETHAND restored the default action: returning re-runs the fault and ends the
     * process normally (tombstone / core), after the report above reached run.err. */
}
LPTOP_LEVEL_EXCEPTION_FILTER SetUnhandledExceptionFilter(LPTOP_LEVEL_EXCEPTION_FILTER f) {
    LPTOP_LEVEL_EXCEPTION_FILTER old = s_filter;
    s_filter = f;
    static int installed;
    if (f && !installed) {
        installed = 1;
        stack_t ss; ss.ss_size = 128 * 1024; ss.ss_sp = malloc(ss.ss_size); ss.ss_flags = 0;
        if (ss.ss_sp) sigaltstack(&ss, NULL);        /* faults on a full fiber stack still report */
        struct sigaction sa; memset(&sa, 0, sizeof sa);
        sa.sa_sigaction = crash_handler;
        sa.sa_flags = SA_SIGINFO | SA_ONSTACK | SA_RESETHAND;
        sigemptyset(&sa.sa_mask);
        sigaction(SIGSEGV, &sa, NULL); sigaction(SIGBUS, &sa, NULL);
        sigaction(SIGILL, &sa, NULL);  sigaction(SIGFPE, &sa, NULL);
    }
    return old;
}

/* ---- fibers ---------------------------------------------------------------------------------
 * The scheduler runs each guest thread on its own host stack and switches by hand. Windows has
 * fibers; Android's libc has no ucontext, so this is a small assembly context switch that saves
 * the callee-saved registers on the old stack and loads them from the new one.
 *   void sr_ctx_switch(void **save_sp, void *new_sp)
 * A fresh fiber's stack is prepared to look like a suspended call so the first switch "returns"
 * into fiber_entry. */
typedef struct Fiber {
    void *sp;
    void *stack;
    size_t size;
    LPFIBER_START_ROUTINE fn;
    void *param;
    int started;
} Fiber;
static Fiber s_main_fiber;
static Fiber *s_cur;
static Fiber *s_starting;

#if defined(__x86_64__)
__asm__(
    ".text\n.globl sr_ctx_switch\n.hidden sr_ctx_switch\n.type sr_ctx_switch,@function\nsr_ctx_switch:\n"
    "  pushq %rbp\n  pushq %rbx\n  pushq %r12\n  pushq %r13\n  pushq %r14\n  pushq %r15\n"
    "  movq %rsp, (%rdi)\n  movq %rsi, %rsp\n"
    "  popq %r15\n  popq %r14\n  popq %r13\n  popq %r12\n  popq %rbx\n  popq %rbp\n"
    "  ret\n.size sr_ctx_switch, .-sr_ctx_switch\n");
#define CTX_FRAME_BYTES 64          /* 6 saved registers + return address + alignment pad */
#define CTX_ENTRY_SLOT  6           /* index (8-byte words) of the return address */
#elif defined(__aarch64__)
__asm__(
    ".text\n.globl sr_ctx_switch\n.hidden sr_ctx_switch\n.type sr_ctx_switch,%function\nsr_ctx_switch:\n"
    "  sub sp, sp, #160\n"
    "  stp x19, x20, [sp, #0]\n  stp x21, x22, [sp, #16]\n  stp x23, x24, [sp, #32]\n"
    "  stp x25, x26, [sp, #48]\n  stp x27, x28, [sp, #64]\n  stp x29, x30, [sp, #80]\n"
    "  stp d8,  d9,  [sp, #96]\n  stp d10, d11, [sp, #112]\n  stp d12, d13, [sp, #128]\n  stp d14, d15, [sp, #144]\n"
    "  mov x2, sp\n  str x2, [x0]\n  mov sp, x1\n"
    "  ldp x19, x20, [sp, #0]\n  ldp x21, x22, [sp, #16]\n  ldp x23, x24, [sp, #32]\n"
    "  ldp x25, x26, [sp, #48]\n  ldp x27, x28, [sp, #64]\n  ldp x29, x30, [sp, #80]\n"
    "  ldp d8,  d9,  [sp, #96]\n  ldp d10, d11, [sp, #112]\n  ldp d12, d13, [sp, #128]\n  ldp d14, d15, [sp, #144]\n"
    "  add sp, sp, #160\n  ret\n.size sr_ctx_switch, .-sr_ctx_switch\n");
#define CTX_FRAME_BYTES 160
#define CTX_ENTRY_SLOT  11          /* x30 (lr) is at byte offset 88 */
#else
#error "fibers: unsupported CPU (x86_64 and aarch64 only)"
#endif
extern void sr_ctx_switch(void **save_sp, void *new_sp);

static void fiber_entry(void) {
    Fiber *f = s_starting;
    f->fn(f->param);
    fprintf(stderr, "fatal: a fiber's start routine returned\n");
    abort();
}

LPVOID ConvertThreadToFiber(LPVOID param) {
    (void)param;
    s_cur = &s_main_fiber; s_main_fiber.started = 1;
    return &s_main_fiber;
}
LPVOID CreateFiberEx(SIZE_T commit, SIZE_T reserve, DWORD flags, LPFIBER_START_ROUTINE fn, LPVOID param) {
    (void)commit; (void)flags;
    const size_t page = (size_t)sysconf(_SC_PAGESIZE);
    size_t size = reserve ? reserve : (1u << 20);
    size = (size + page - 1) & ~(page - 1);
    Fiber *f = (Fiber *)calloc(1, sizeof *f);
    if (!f) return NULL;
    /* Lazily committed: untouched pages cost nothing, so a 64 MB stack per guest thread is cheap. */
    void *base = mmap(NULL, size, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS | MAP_NORESERVE, -1, 0);
    if (base == MAP_FAILED) { free(f); return NULL; }
    mprotect(base, page, PROT_NONE);                         /* guard page at the low end */
    f->stack = base; f->size = size; f->fn = fn; f->param = param;
    uintptr_t top = ((uintptr_t)base + size) & ~(uintptr_t)15;
    uintptr_t *sp = (uintptr_t *)(top - CTX_FRAME_BYTES);
    memset(sp, 0, CTX_FRAME_BYTES);
    sp[CTX_ENTRY_SLOT] = (uintptr_t)fiber_entry;
    f->sp = sp;
    return f;
}
void SwitchToFiber(LPVOID fiber) {
    Fiber *to = (Fiber *)fiber, *from = s_cur;
    if (!to || to == from) return;
    if (!to->started) { to->started = 1; s_starting = to; }
    s_cur = to;
    sr_ctx_switch(&from->sp, to->sp);
    /* resumed: whoever switched back to us has already set s_cur */
}
void DeleteFiber(LPVOID fiber) {
    Fiber *f = (Fiber *)fiber;
    if (!f || f == &s_main_fiber || f == s_cur) return;
    munmap(f->stack, f->size);
    free(f);
}

/* ---- GDI / GDI+ stubs (see windows.h): everything reports failure ------------------------ */
HDC CreateCompatibleDC(HDC dc) { (void)dc; return (HDC)1; }
HFONT CreateFontA(int h, int w, int esc, int ori, int weight, DWORD it, DWORD ul, DWORD so, DWORD cs,
                  DWORD op, DWORD cp, DWORD q, DWORD pf, const char *face) {
    (void)h; (void)w; (void)esc; (void)ori; (void)weight; (void)it; (void)ul; (void)so; (void)cs;
    (void)op; (void)cp; (void)q; (void)pf; (void)face;
    return (HFONT)1;
}
HGDIOBJ SelectObject(HDC dc, HGDIOBJ o) { (void)dc; (void)o; return (HGDIOBJ)1; }
BOOL GetTextExtentPoint32A(HDC dc, const char *s, int n, SIZE *sz) { (void)dc; (void)s; (void)n; sz->cx = sz->cy = 0; return FALSE; }
DWORD GetTabbedTextExtentA(HDC dc, const char *s, int n, int nt, const INT *tabs) { (void)dc; (void)s; (void)n; (void)nt; (void)tabs; return 0; }
HBITMAP CreateDIBSection(HDC dc, const BITMAPINFO *bi, UINT usage, void **bits, HANDLE sect, DWORD off) {
    (void)dc; (void)bi; (void)usage; (void)sect; (void)off; if (bits) *bits = NULL; return NULL;   /* callers treat NULL as "no text" */
}
int SetBkMode(HDC dc, int mode) { (void)dc; (void)mode; return 0; }
COLORREF SetTextColor(HDC dc, COLORREF c) { (void)dc; (void)c; return 0; }
BOOL TextOutA(HDC dc, int x, int y, const char *s, int n) { (void)dc; (void)x; (void)y; (void)s; (void)n; return FALSE; }
LONG TabbedTextOutA(HDC dc, int x, int y, const char *s, int n, int nt, const INT *tabs, int origin) {
    (void)dc; (void)x; (void)y; (void)s; (void)n; (void)nt; (void)tabs; (void)origin; return 0;
}
BOOL GdiFlush(void) { return TRUE; }
BOOL DeleteObject(HGDIOBJ o) { (void)o; return TRUE; }
BOOL DeleteDC(HDC dc) { (void)dc; return TRUE; }
int _snwprintf(WCHAR *buf, size_t count, const wchar_t *fmt, ...) { (void)fmt; if (buf && count) buf[0] = 0; return -1; }

/* sdl3vk.c declares these itself (GDI+ flat API); a non-zero return means "failed". */
int GdiplusStartup(void *token, const void *in, void *out) { (void)token; (void)in; (void)out; return 1; }
int GdipCreateBitmapFromScan0(int w, int h, int stride, int fmt, void *scan0, void **bmp) { (void)w; (void)h; (void)stride; (void)fmt; (void)scan0; if (bmp) *bmp = NULL; return 1; }
int GdipSaveImageToFile(void *img, const void *file, const void *clsid, const void *params) { (void)img; (void)file; (void)clsid; (void)params; return 1; }
int GdipDisposeImage(void *img) { (void)img; return 0; }
int GdipCreateBitmapFromFile(const void *file, void **bmp) { (void)file; if (bmp) *bmp = NULL; return 1; }
int GdipGetImageWidth(void *img, unsigned *w) { (void)img; if (w) *w = 0; return 1; }
int GdipGetImageHeight(void *img, unsigned *h) { (void)img; if (h) *h = 0; return 1; }
int GdipBitmapLockBits(void *bmp, const void *rect, unsigned flags, int fmt, void *data) { (void)bmp; (void)rect; (void)flags; (void)fmt; (void)data; return 1; }
int GdipBitmapUnlockBits(void *bmp, void *data) { (void)bmp; (void)data; return 0; }
