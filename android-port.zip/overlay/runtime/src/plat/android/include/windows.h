/* Win32 compatibility shim for the Android (bionic/Linux) build of the runtime.
 *
 * The runtime was written for Windows. Rather than editing every file that calls a Win32
 * function, the Android build puts this directory first on the include path, so
 * `#include <windows.h>` finds THIS header. It declares just the Win32 subset the runtime
 * uses, implemented on POSIX in ../shim.c. Consequence: when the upstream project changes
 * Windows-only code, most changes merge without touching the port. If upstream starts using
 * a Win32 call that is missing here, the Android build fails with an "undeclared" error and
 * the fix is one function in this shim, not a patch of upstream code.
 *
 * Not a general Win32 layer. Things that cannot be shimmed meaningfully (GDI text drawing,
 * GDI+ PNG, Media Foundation, waveOut, winsock) are stubs or replaced files; see
 * ../README.md.
 */
#ifndef SR_ANDROID_WINDOWS_H
#define SR_ANDROID_WINDOWS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stddef.h>
#include <stdarg.h>
#include <wchar.h>
#include <errno.h>
#include <time.h>
#include <unistd.h>
#include <strings.h>
#include <sys/types.h>
#include <sys/stat.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ---- calling conventions / export ------------------------------------------------------ */
#define WINAPI
#define CALLBACK
#define APIENTRY
#define __stdcall
#define __cdecl
#define __declspec(x) __attribute__((visibility("default")))

/* ---- basic types ------------------------------------------------------------------------ */
typedef int            BOOL;
typedef int32_t        INT, LONG;
typedef int16_t        SHORT;
typedef uint32_t       UINT, UINT32, DWORD, ULONG;
typedef uint16_t       WORD, WCHAR;
typedef uint8_t        BYTE;
typedef int64_t        LONGLONG, INT64;
typedef uint64_t       ULONGLONG, UINT64;
typedef uintptr_t      UINT_PTR, ULONG_PTR, DWORD_PTR;
typedef size_t         SIZE_T;
typedef void           VOID;
typedef void          *LPVOID, *HANDLE, *HMODULE, *HINSTANCE, *HWND, *HDC, *HFONT, *HBITMAP, *HGDIOBJ;
typedef const char    *LPCSTR;
typedef char          *LPSTR;
typedef DWORD          COLORREF;
#define TRUE  1
#define FALSE 0
#define MAX_PATH 1024      /* Windows' 260 is too small for Android storage paths */
#define INVALID_HANDLE_VALUE ((HANDLE)(intptr_t)-1)

typedef union _LARGE_INTEGER {
    struct { DWORD LowPart; LONG HighPart; };
    LONGLONG QuadPart;
} LARGE_INTEGER;

typedef struct _FILETIME { DWORD dwLowDateTime, dwHighDateTime; } FILETIME;
typedef struct _SYSTEMTIME {
    WORD wYear, wMonth, wDayOfWeek, wDay, wHour, wMinute, wSecond, wMilliseconds;
} SYSTEMTIME;

/* ---- timing ----------------------------------------------------------------------------- */
/* Counter in nanoseconds relative to the first call (small values: no precision loss when the
 * runtime converts through double). */
BOOL QueryPerformanceFrequency(LARGE_INTEGER *f);
BOOL QueryPerformanceCounter(LARGE_INTEGER *c);
void Sleep(DWORD ms);
ULONGLONG GetTickCount64(void);
static inline UINT timeBeginPeriod(UINT p) { (void)p; return 0; }
static inline UINT timeEndPeriod(UINT p) { (void)p; return 0; }
void GetSystemTimeAsFileTime(FILETIME *ft);
void GetLocalTime(SYSTEMTIME *st);
BOOL FileTimeToSystemTime(const FILETIME *ft, SYSTEMTIME *st);
BOOL FileTimeToLocalFileTime(const FILETIME *ft, FILETIME *local);
LONG CompareFileTime(const FILETIME *a, const FILETIME *b);

/* ---- fibers (the scheduler runs each guest thread on one) ------------------------------- */
typedef void (CALLBACK *LPFIBER_START_ROUTINE)(void *param);
LPVOID ConvertThreadToFiber(LPVOID param);
LPVOID CreateFiberEx(SIZE_T commit, SIZE_T reserve, DWORD flags, LPFIBER_START_ROUTINE fn, LPVOID param);
void SwitchToFiber(LPVOID fiber);
void DeleteFiber(LPVOID fiber);

/* ---- files and directories -------------------------------------------------------------- */
/* All path arguments accept '\' as well as '/' (converted), as Windows does. */
#define FILE_ATTRIBUTE_READONLY   0x00000001
#define FILE_ATTRIBUTE_DIRECTORY  0x00000010
#define FILE_ATTRIBUTE_NORMAL     0x00000080
#define INVALID_FILE_ATTRIBUTES   ((DWORD)0xFFFFFFFFu)
#define MOVEFILE_REPLACE_EXISTING 0x1
#define MOVEFILE_WRITE_THROUGH    0x8
#define ERROR_FILE_NOT_FOUND      2
#define ERROR_PATH_NOT_FOUND      3
#define ERROR_ACCESS_DENIED       5
#define ERROR_DIR_NOT_EMPTY       145
#define ERROR_ALREADY_EXISTS      183

typedef struct _WIN32_FIND_DATAA {
    DWORD dwFileAttributes;
    FILETIME ftCreationTime, ftLastAccessTime, ftLastWriteTime;
    DWORD nFileSizeHigh, nFileSizeLow, dwReserved0, dwReserved1;
    char cFileName[MAX_PATH];
    char cAlternateFileName[14];
} WIN32_FIND_DATAA;
typedef struct _WIN32_FILE_ATTRIBUTE_DATA {
    DWORD dwFileAttributes;
    FILETIME ftCreationTime, ftLastAccessTime, ftLastWriteTime;
    DWORD nFileSizeHigh, nFileSizeLow;
} WIN32_FILE_ATTRIBUTE_DATA;
typedef enum { GetFileExInfoStandard = 0 } GET_FILEEX_INFO_LEVELS;

DWORD GetLastError(void);
BOOL  CreateDirectoryA(const char *path, void *security);
BOOL  RemoveDirectoryA(const char *path);
BOOL  DeleteFileA(const char *path);
BOOL  CopyFileA(const char *from, const char *to, BOOL failIfExists);
BOOL  MoveFileExA(const char *from, const char *to, DWORD flags);
DWORD GetFileAttributesA(const char *path);
BOOL  GetFileAttributesExA(const char *path, GET_FILEEX_INFO_LEVELS level, void *data);
HANDLE FindFirstFileA(const char *pattern, WIN32_FIND_DATAA *fd);
BOOL  FindNextFileA(HANDLE h, WIN32_FIND_DATAA *fd);
BOOL  FindClose(HANDLE h);
BOOL  SetCurrentDirectoryA(const char *dir);
DWORD GetModuleFileNameA(HMODULE m, char *buf, DWORD size);

/* libc entry points that take paths: wrapped so '\' separators written for Windows work. */
FILE *sr_fopen(const char *path, const char *mode);
int   sr_remove(const char *path);
int   sr_rename(const char *from, const char *to);
int   sr_mkdir(const char *path);
#define fopen(p, m)    sr_fopen((p), (m))
#define remove(p)      sr_remove(p)
#define rename(a, b)   sr_rename((a), (b))
#define _mkdir(p)      sr_mkdir(p)

/* ---- MSVCRT names (sr_msvcrt.h) ----------------------------------------------------------- */
#include "sr_msvcrt.h"
int _snwprintf(WCHAR *buf, size_t count, const wchar_t *fmt, ...);   /* stub: see shim.c */

/* ---- dynamic libraries (game.dll is built as libgame.so) --------------------------------- */
HMODULE LoadLibraryA(const char *name);
void   *GetProcAddress(HMODULE m, const char *name);
BOOL    FreeLibrary(HMODULE m);

/* ---- message boxes, console, window leftovers --------------------------------------------- */
#define MB_OK              0x0
#define MB_ICONERROR       0x10
#define MB_ICONWARNING     0x30
#define MB_ICONINFORMATION 0x40
#define SW_HIDE            0
int   MessageBoxA(HWND parent, const char *text, const char *caption, UINT type);
DWORD GetConsoleProcessList(DWORD *pids, DWORD n);
HWND  GetConsoleWindow(void);
BOOL  ShowWindow(HWND w, int cmd);

/* ---- crash reporting (SetUnhandledExceptionFilter via POSIX signals) ---------------------- */
#define EXCEPTION_ACCESS_VIOLATION 0xC0000005u
#define EXCEPTION_ILLEGAL_INSTRUCTION 0xC000001Du
#define EXCEPTION_CONTINUE_SEARCH 0
typedef struct _EXCEPTION_RECORD {
    DWORD ExceptionCode, ExceptionFlags;
    struct _EXCEPTION_RECORD *ExceptionRecord;
    void *ExceptionAddress;
    DWORD NumberParameters;
    ULONG_PTR ExceptionInformation[15];
} EXCEPTION_RECORD;
typedef struct _EXCEPTION_POINTERS { EXCEPTION_RECORD *ExceptionRecord; void *ContextRecord; } EXCEPTION_POINTERS;
typedef LONG (WINAPI *LPTOP_LEVEL_EXCEPTION_FILTER)(EXCEPTION_POINTERS *);
LPTOP_LEVEL_EXCEPTION_FILTER SetUnhandledExceptionFilter(LPTOP_LEVEL_EXCEPTION_FILTER f);

/* ---- atomics ------------------------------------------------------------------------------ */
static inline LONG InterlockedExchange(volatile LONG *p, LONG v) { return __atomic_exchange_n(p, v, __ATOMIC_SEQ_CST); }
static inline LONG InterlockedIncrement(volatile LONG *p) { return __atomic_add_fetch(p, 1, __ATOMIC_SEQ_CST); }
static inline LONG InterlockedDecrement(volatile LONG *p) { return __atomic_sub_fetch(p, 1, __ATOMIC_SEQ_CST); }

/* ---- GDI / GDI+ ---------------------------------------------------------------------------
 * Text drawing (toast, Esc menu, FPS counter) and PNG read/write use GDI and GDI+ on Windows.
 * Here they are stubs that report failure, which the callers already handle: no text/PNG yet.
 * (Planned: a real mini-GDI backed by the game's own PGF font, so these files stay unpatched.) */
typedef struct { LONG cx, cy; } SIZE;
typedef struct { DWORD biSize; LONG biWidth, biHeight; WORD biPlanes, biBitCount; DWORD biCompression, biSizeImage;
                 LONG biXPelsPerMeter, biYPelsPerMeter; DWORD biClrUsed, biClrImportant; } BITMAPINFOHEADER;
typedef struct { BITMAPINFOHEADER bmiHeader; DWORD bmiColors[1]; } BITMAPINFO;
#define RGB(r, g, b) ((COLORREF)(((BYTE)(r)) | ((WORD)((BYTE)(g)) << 8) | (((DWORD)(BYTE)(b)) << 16)))
#define BI_RGB 0
#define DIB_RGB_COLORS 0
#define TRANSPARENT 1
#define FW_SEMIBOLD 600
#define FW_BOLD 700
#define DEFAULT_CHARSET 1
#define OUT_DEFAULT_PRECIS 0
#define CLIP_DEFAULT_PRECIS 0
#define ANTIALIASED_QUALITY 4
#define DEFAULT_PITCH 0
HDC     CreateCompatibleDC(HDC dc);
HFONT   CreateFontA(int h, int w, int esc, int ori, int weight, DWORD it, DWORD ul, DWORD so, DWORD cs,
                    DWORD op, DWORD cp, DWORD q, DWORD pf, const char *face);
HGDIOBJ SelectObject(HDC dc, HGDIOBJ o);
BOOL    GetTextExtentPoint32A(HDC dc, const char *s, int n, SIZE *sz);
DWORD   GetTabbedTextExtentA(HDC dc, const char *s, int n, int ntabs, const INT *tabs);
HBITMAP CreateDIBSection(HDC dc, const BITMAPINFO *bi, UINT usage, void **bits, HANDLE sect, DWORD off);
int     SetBkMode(HDC dc, int mode);
COLORREF SetTextColor(HDC dc, COLORREF c);
BOOL    TextOutA(HDC dc, int x, int y, const char *s, int n);
LONG    TabbedTextOutA(HDC dc, int x, int y, const char *s, int n, int ntabs, const INT *tabs, int origin);
BOOL    GdiFlush(void);
BOOL    DeleteObject(HGDIOBJ o);
BOOL    DeleteDC(HDC dc);
/* The Gdip* functions are declared by their only user (sdl3vk.c); shim.c defines them as stubs. */
typedef struct { UINT32 Data1; WORD Data2, Data3; BYTE Data4[8]; } CLSID;

#ifdef __cplusplus
}
#endif
#endif /* SR_ANDROID_WINDOWS_H */
