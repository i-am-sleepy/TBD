/* MSVCRT-only names the runtime uses. Force-included into every runtime C file by the Android
 * build (CMake: -include sr_msvcrt.h), because some files (iso.c) use them without including
 * <windows.h>; windows.h includes it too. */
#ifndef SR_MSVCRT_H
#define SR_MSVCRT_H
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#ifndef _stricmp
#define _stricmp   strcasecmp
#define _strnicmp  strncasecmp
#define _putenv    putenv
#define _fseeki64  fseeko     /* arm64-v8a: off_t is 64-bit */
#define _ftelli64  ftello
#endif
#endif
