/* <direct.h> shim: _mkdir comes from windows.h's wrapper. */
#include <windows.h>
