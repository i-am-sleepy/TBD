#!/usr/bin/env bash
# Build the Termux kit zip: what prepare.sh needs to turn YOUR disc image into libgame.so
# (translation scripts, headers, the game description, eboot_decrypt's source). No game code.
#   bash android/make_kit.sh <out.zip>
set -eu
cd "$(dirname "$0")/.."
OUT="$(realpath -m "${1:?usage: make_kit.sh <out.zip>}")"
K=$(mktemp -d)/kit; mkdir -p $K/tools $K/rt $K/versions $K/eboot_decrypt
cp runtime/tools/{prxload,imports,analyze,codegen}.py tools/{split_recomp,toml_addrs,mods_gen,write_launch_cfg,prepare}.py $K/tools/
cp runtime/src/rt/recomp.h runtime/src/rt/game_glue.c $K/rt/
cp versions/ULUS10567.toml $K/versions/
cp -r runtime/third_party/eboot_decrypt/. $K/eboot_decrypt/
cp android/termux/prepare.sh android/termux/prepare_android.py $K/
cp runtime/src/plat/android/include/sr_msvcrt.h $K/sr_msvcrt.h   # eboot_decrypt.cpp uses _fseeki64/_stricmp
cp runtime/LICENSE $K/LICENSE
bash android/kit_id.sh > $K/kit_id.txt
rm -f "$OUT"; ( cd "$(dirname $K)" && zip -qr "$OUT" kit )
echo "kit $(cat $K/kit_id.txt) -> $OUT"
