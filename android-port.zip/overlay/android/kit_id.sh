#!/usr/bin/env bash
# Kit id: changes when the translation tools, headers or the game description change. Same
# formula and file order as scripts/make_kit.sh (tools/*.py, rt/*, versions/*), so the id of
# the PC kit and of this one agree for the same sources.
set -eu
cd "$(dirname "$0")/.."
T=$(mktemp -d); mkdir -p $T/tools $T/rt $T/versions
cp runtime/tools/{prxload,imports,analyze,codegen}.py tools/{split_recomp,toml_addrs,mods_gen,write_launch_cfg,prepare}.py $T/tools/
cp runtime/src/rt/recomp.h runtime/src/rt/game_glue.c $T/rt/
cp versions/ULUS10567.toml $T/versions/
( cat $T/tools/*.py $T/rt/* $T/versions/* ) | sha1sum | cut -c1-16
rm -rf $T
