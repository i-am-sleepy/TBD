# The 3rd Birthday recomp: Android port

Runs the recompiled game on an Android phone. Like the PC version it contains **no game code**:
the app is the runtime (renderer, audio, system emulation), and the game library `libgame.so` is
built **on your phone, from your own disc image**, by a script you run in Termux.

Status: **first milestone, untested on a device.** Expect to iterate. See "Known gaps".

## What you need
- An Android phone with Vulkan 1.1 (arm64), your own disc image of *Parasite Eve: The 3rd
  Birthday* (USA, ULUS10567) as an `.iso` on the phone, about 2 GB free.
- A free GitHub account (builds the APK), Termux (builds the game library),
  MT Manager or any APK signer (signs the APK).

## 1. Set up a GitHub repo (once, in the browser)
Create a NEW empty repo (private is fine). Upload `android-port.zip` to it (Add file > Upload
files; do not unzip it). Then Add file > Create new file, name it `.github/workflows/android.yml`
and paste the workflow text. There is no fork, no Git in Termux, and no patching by hand: the
workflow downloads the upstream project, adds this port on top, and builds.

## 2. Build the APK (GitHub)
Repo > **Actions** > "Android APK" > **Run workflow** (it also runs when you upload a new
`android-port.zip`). Takes about 10 to 20 minutes. Download the artifact
`the3rdbirthday-android`: it holds `the3rdbirthday-unsigned.apk` and `termux-kit.zip`.
The run builds the upstream commit it was tested with by default; type `master` in the
"upstream_ref" box to build the newest upstream instead. If the run fails, open it, copy the red
error lines and send them to me.

## 3. Sign and install
Sign `the3rdbirthday-unsigned.apk` with MT Manager (v1+v2+v3 signature, keep the same key every
time so updates install over the old app), then install it.

## 4. Build the game library (Termux)
Copy `termux-kit.zip` to the phone, then in Termux:

    termux-setup-storage            # once; allow access
    unzip /sdcard/Download/termux-kit.zip -d ~
    cd ~/kit
    bash prepare.sh /sdcard/Download/your-game.iso 3

The `3` is the number of parallel compile jobs: higher is faster but can run out of memory.
This is slow (the game is translated to C and compiled): keep Termux open and the screen on.
Android 12+ may kill Termux's compiler processes; with Shizuku or wireless debugging you can run
`adb shell settings put global settings_enable_monitor_phantom_procs false`, and in Termux use
`termux-wake-lock` (prepare.sh does this). It writes `/sdcard/The3rdBirthday/`.

## 5. Play
Open **The 3rd Birthday**, allow file access, wait for "Ready", tap **Start game**. On-screen
controls appear over the game (the `=` button at the top is the Esc menu). A Bluetooth/USB gamepad
also works.

## Updating when upstream changes
1. Actions > Run workflow, with `master` in "upstream_ref" (newest upstream). If the "Apply the
   Android port" step fails, upstream changed a file the port edits: send me the error.
2. Download both files, sign and install the new APK.
3. If the app says the game library is from another kit, run `prepare.sh` again with the new
   `termux-kit.zip`. (Not every update changes the kit: only changes to the translation scripts,
   headers or game description do.)

## How it is built (for the curious)
- `runtime/src/plat/android/include/windows.h` + `shim.c`: a small Win32 compatibility layer
  (files, time, fibers, LoadLibrary, crash handler). Upstream code compiles against it unchanged,
  so upstream updates merge without touching the port. Tests: `plat/android/test/test_shim.c`.
- Replaced Windows-only files (selected in `android/app/jni/CMakeLists.txt`):
  `audio.c` -> `audio_sdl.c`, `h264_mf.c` -> `h264_stub.c`, `osk_win.c` -> `osk_stub.c`,
  `ctrl_server.c` -> `ctrl_stub.c`, `update.c` -> `update_stub.c`,
  `texpack_ppsspp.c` -> `texpack_stub.c`. `touch_pad.c` feeds the touch overlay in as a virtual
  gamepad. Edited upstream files: `gui.c` (Windows window/gamepad code fenced with `#ifdef _WIN32`),
  `driver.c` (one line: path separator).
- `android/termux/prepare_android.py` runs the kit's own `prepare.py` with a few strings patched in
  memory (no fork of that file). Build flags that matter on arm64: `-fsigned-char`,
  `-ffp-contract=off`, `-fPIC`.

## Known gaps (first build)
- **No text yet**: the Esc menu, toasts and FPS counter draw nothing (GDI text is stubbed).
- **No movies**: H.264 decoding is stubbed, so cutscene movies show no picture.
- **No on-screen keyboard** for name entry (returns "cancel"); no screenshots; no texture packs.
- **Performance is unknown** on a Snapdragon 685. Defaults are the lightest: PSP resolution
  (`render_scale=1`), no frame interpolation, no glow.
- aarch64 fiber switching and the JNI/SDL virtual-gamepad code were written without a device to
  test on.
- Memory-stick file names are case-sensitive on Android (they are not on Windows).
