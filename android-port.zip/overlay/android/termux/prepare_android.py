#!/usr/bin/env python3
"""Termux front end for the upstream prepare.py.

The upstream script builds game.dll on Windows with MinGW gcc. It already takes --gcc, a kit
folder and an ISO; only a few hard-coded details differ on Android. Instead of forking
prepare.py (which would conflict every time upstream changes it), this wrapper loads the kit's
own tools/prepare.py, patches those few strings in memory, and runs it. If upstream changes one
of them the assertion below says exactly which, and the fix is one line here.

    python3 prepare_android.py --iso game.iso --game-dir <work dir> --kit <kit dir> --gcc clang

Differences handled:
  * eboot_decrypt.exe        -> eboot_decrypt (built from source by prepare.sh)
  * -fPIC / -fvisibility     -> needed for an ELF shared library (a PE DLL needs neither)
  * -fsigned-char            -> plain char is unsigned on arm64, signed on the x86 the code assumed
  * -ffp-contract=off        -> no fused multiply-add: floats stay bit-identical to PSP/x86
  * __declspec(dllexport)    -> visibility("default") on the 4 entry points game_glue.c exports
  * -static-libgcc           -> -lm (and 16 KB page alignment for Android 15+ devices)
The result is written as game.dll; prepare.sh renames it libgame.so (the Android app's
LoadLibrary shim maps "game.dll" to "libgame.so").
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
PREPARE = os.path.join(HERE, "tools", "prepare.py")

EXTRA = ('"-fPIC", "-fsigned-char", "-ffp-contract=off", "-fvisibility=hidden", '
         '"-D__declspec(x)=__attribute__((visibility(\\"default\\")))"')

PATCHES = [
    ('"eboot_decrypt.exe"', '"eboot_decrypt"', 1),
    ('"-DSR_GAME_DLL"', '"-DSR_GAME_DLL", ' + EXTRA, None),     # every compile command
    ('"-static-libgcc"', '"-lm", "-Wl,-z,max-page-size=16384"', 1),
]


def patched_source():
    src = open(PREPARE, encoding="utf-8").read()
    for old, new, want in PATCHES:
        n = src.count(old)
        if n == 0 or (want is not None and n != want):
            raise SystemExit(f"prepare_android.py: upstream prepare.py changed: expected {want or '>=1'} "
                             f"occurrence(s) of {old}, found {n}. Update PATCHES in this file.")
        src = src.replace(old, new)
    return src


if __name__ == "__main__":
    src = patched_source()
    code = compile(src, PREPARE, "exec")
    if "--selftest" in sys.argv:
        print("patches apply; patched prepare.py compiles")
        sys.exit(0)
    sys.argv[0] = PREPARE
    exec(code, {"__name__": "__main__", "__file__": PREPARE})
