#!/data/data/com.termux/files/usr/bin/bash
# Turn YOUR disc image into the game library the Android app loads. Run in Termux, from the
# unzipped kit folder:
#     bash prepare.sh /storage/emulated/0/Download/your-game.iso [jobs]
# Takes a while (the game is translated to C and compiled on the phone) - keep Termux open,
# the screen on and the phone cool. Nothing is downloaded except Termux packages (python, clang).
# Output: /storage/emulated/0/The3rdBirthday/  (the app imports it from there)
set -eu
KIT="$(cd "$(dirname "$0")" && pwd)"
ISO_IN="${1:-}"
JOBS="${2:-3}"
OUT="${SR_OUT:-/storage/emulated/0/The3rdBirthday}"
WORK="${SR_WORK:-$HOME/the3rdbirthday-build}"

if [ -z "$ISO_IN" ]; then echo "usage: bash prepare.sh /path/to/game.iso [jobs]"; exit 2; fi
if [ ! -r "$ISO_IN" ]; then
  echo "Cannot read $ISO_IN. If it is on the phone's storage run 'termux-setup-storage' once and allow access."; exit 2
fi
ISO="$(realpath "$ISO_IN")"
[ -d /storage/emulated/0 ] || { echo "Shared storage not visible: run 'termux-setup-storage' once."; exit 2; }

command -v termux-wake-lock >/dev/null 2>&1 && termux-wake-lock || true
for p in python clang; do
  command -v $p >/dev/null 2>&1 || { echo "Installing $p ..."; pkg install -y $p; }
done
CC=clang; CXX=clang++

# 1. the disc decrypter (small C++ program, built once)
if [ ! -x "$KIT/tools/eboot_decrypt" ]; then
  echo "Building eboot_decrypt ..."
  ED="$KIT/eboot_decrypt"; T="$(mktemp -d)"
  for c in AES SHA1 bn ec kirk_engine amctrl; do $CC -O2 -w -c "$ED/libkirk/$c.c" -o "$T/$c.o"; done
  $CXX -std=c++17 -O2 -w -include "$KIT/sr_msvcrt.h" -I"$ED/shim" -I"$ED" "$ED/eboot_decrypt.cpp" "$ED/PrxDecrypter.cpp" "$T"/*.o -o "$KIT/tools/eboot_decrypt"
  rm -rf "$T"
fi

# 2. translate + compile + link (upstream's prepare.py, adapted by prepare_android.py)
mkdir -p "$WORK" "$OUT"
echo "Using $JOBS compile jobs (more is faster but can run out of memory; pass a number as 2nd argument)."
python3 "$KIT/prepare_android.py" --iso "$ISO" --game-dir "$WORK" --kit "$KIT" --gcc "$CC" --jobs "$JOBS"

# 3. hand the result to the app
mv -f "$WORK/game.dll" "$WORK/libgame.so"
grep -v '^iso=' "$WORK/launch.cfg" > "$WORK/launch.cfg.new" || true
echo "iso=$ISO" >> "$WORK/launch.cfg.new"; mv -f "$WORK/launch.cfg.new" "$WORK/launch.cfg"
for f in libgame.so image.bin launch.cfg init.trace game_build.txt; do cp -f "$WORK/$f" "$OUT/$f"; done
echo
echo "Done. Open the app: it imports the game from $OUT and starts."
