#!/usr/bin/env bash
# Prepare the Android project for building (CI runs this; you can too):
#   bash android/stage.sh [sdl-git-ref]
# - fetches SDL3 into app/jni/SDL and copies its Java half into the app
# - copies the runtime's data files (fonts, VFPU tables) into the APK's assets
# - writes the kit id (same formula as scripts/make_kit.sh) so the app can tell whether the
#   libgame.so Termux built matches this APK
set -eu
cd "$(dirname "$0")/.."
ROOT="$PWD"
SDL_REF="${1:-release-3.2.x}"
APP=android/app

if [ ! -f $APP/jni/SDL/CMakeLists.txt ]; then
  git clone --depth 1 --branch "$SDL_REF" https://github.com/libsdl-org/SDL.git $APP/jni/SDL \
    || { echo "SDL ref '$SDL_REF' not found; falling back to the default branch"; \
         git clone --depth 1 https://github.com/libsdl-org/SDL.git $APP/jni/SDL; }
  git -C $APP/jni/SDL log -1 --format='SDL checkout: %h %s'; ls $APP/jni/SDL/android-project/app/src/main/java/org/libsdl/app >/dev/null
fi
mkdir -p $APP/src/main/java/org/libsdl/app
cp $APP/jni/SDL/android-project/app/src/main/java/org/libsdl/app/*.java $APP/src/main/java/org/libsdl/app/

rm -rf $APP/src/main/assets; mkdir -p $APP/src/main/assets
cp -r runtime/font   $APP/src/main/assets/font
cp -r runtime/assets $APP/src/main/assets/assets
bash android/kit_id.sh > $APP/src/main/assets/kit_id.txt
echo "staged: SDL $SDL_REF, kit $(cat $APP/src/main/assets/kit_id.txt)"
