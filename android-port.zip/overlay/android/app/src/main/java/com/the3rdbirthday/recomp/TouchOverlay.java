package com.the3rdbirthday.recomp;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;

import org.libsdl.app.SDLActivity;

/** Translucent on-screen PSP controls drawn over the game. Touches become a virtual gamepad
 *  (see touch_pad.c); the menu button sends Escape, which opens the runtime's Esc menu. */
public class TouchOverlay extends View {

    static native void nativePad(int buttons, int lx, int ly);

    // button bits (must match touch_pad.c)
    private static final int CROSS = 0, CIRCLE = 1, SQUARE = 2, TRIANGLE = 3, SELECT = 4, START = 5,
            L = 6, R = 7, UP = 8, DOWN = 9, LEFT = 10, RIGHT = 11, MENU = 12;
    private static final String[] LABELS = { "X", "O", "[]", "/\\", "SEL", "STA", "L", "R", "^", "v", "<", ">", "=" };

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Rect[] rects = new Rect[13];
    private final int[] owner = new int[13];          // pointer id holding each button, or -1
    private int stickPointer = -1;
    private float stickCx, stickCy, stickR, stickX, stickY;
    private int lastButtons = -1, lastLx = 0, lastLy = 0;
    private boolean menuDown = false;

    public TouchOverlay(Context ctx) {
        super(ctx);
        for (int i = 0; i < owner.length; i++) { owner[i] = -1; rects[i] = new Rect(); }
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeWidth(4f);
        line.setColor(0xB0FFFFFF);
        text.setColor(0xD0FFFFFF);
        text.setTextAlign(Paint.Align.CENTER);
        setFocusable(false);
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        int u = Math.min(w, h) / 100;                 // layout unit
        int b = 13 * u;                               // face / d-pad button size
        int fx = (int) (w * 0.86f), fy = (int) (h * 0.62f), d = (int) (b * 1.15f);
        set(CROSS, fx, fy + d, b);
        set(CIRCLE, fx + d, fy, b);
        set(SQUARE, fx - d, fy, b);
        set(TRIANGLE, fx, fy - d, b);
        int dx = (int) (w * 0.14f), dy = (int) (h * 0.34f);
        set(UP, dx, dy - d, b);
        set(DOWN, dx, dy + d, b);
        set(LEFT, dx - d, dy, b);
        set(RIGHT, dx + d, dy, b);
        rects[L].set((int) (w * 0.02f), u * 2, (int) (w * 0.16f), u * 12);
        rects[R].set((int) (w * 0.84f), u * 2, (int) (w * 0.98f), u * 12);
        int sw = 16 * u, sh = 8 * u, sy = h - sh - u * 3;
        rects[SELECT].set((int) (w * 0.5f) - sw - u * 2, sy, (int) (w * 0.5f) - u * 2, sy + sh);
        rects[START].set((int) (w * 0.5f) + u * 2, sy, (int) (w * 0.5f) + sw + u * 2, sy + sh);
        rects[MENU].set((int) (w * 0.5f) - 5 * u, u * 2, (int) (w * 0.5f) + 5 * u, u * 2 + 8 * u);
        stickCx = w * 0.14f; stickCy = h * 0.76f; stickR = 15 * u;
        text.setTextSize(5 * u);
    }

    private void set(int i, int cx, int cy, int size) {
        rects[i].set(cx - size / 2, cy - size / 2, cx + size / 2, cy + size / 2);
    }

    @Override
    protected void onDraw(Canvas c) {
        for (int i = 0; i < rects.length; i++) {
            Rect r = rects[i];
            fill.setColor(owner[i] >= 0 ? 0x70FFFFFF : 0x30000000);
            if (i <= TRIANGLE) {
                c.drawCircle(r.centerX(), r.centerY(), r.width() / 2f, fill);
                c.drawCircle(r.centerX(), r.centerY(), r.width() / 2f, line);
            } else {
                c.drawRect(r, fill);
                c.drawRect(r, line);
            }
            c.drawText(LABELS[i], r.centerX(), r.centerY() + text.getTextSize() / 3f, text);
        }
        fill.setColor(0x30000000);
        c.drawCircle(stickCx, stickCy, stickR, fill);
        c.drawCircle(stickCx, stickCy, stickR, line);
        fill.setColor(0x70FFFFFF);
        c.drawCircle(stickCx + stickX * stickR, stickCy + stickY * stickR, stickR * 0.45f, fill);
    }

    private int hitButton(float x, float y) {
        for (int i = 0; i < rects.length; i++) if (rects[i].contains((int) x, (int) y)) return i;
        return -1;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int action = e.getActionMasked();
        int idx = e.getActionIndex();
        if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
            int id = e.getPointerId(idx);
            float x = e.getX(idx), y = e.getY(idx);
            int hit = hitButton(x, y);
            if (hit >= 0) owner[hit] = id;
            else if (Math.hypot(x - stickCx, y - stickCy) < stickR * 1.8f) stickPointer = id;
        } else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_POINTER_UP
                || action == MotionEvent.ACTION_CANCEL) {
            if (action == MotionEvent.ACTION_CANCEL) {
                for (int i = 0; i < owner.length; i++) owner[i] = -1;
                stickPointer = -1;
            } else {
                int id = e.getPointerId(idx);
                for (int i = 0; i < owner.length; i++) if (owner[i] == id) owner[i] = -1;
                if (stickPointer == id) stickPointer = -1;
            }
        }
        // a finger that slides off a button releases it; one that slides onto a free button presses it
        for (int p = 0; p < e.getPointerCount(); p++) {
            int id = e.getPointerId(p);
            float x = e.getX(p), y = e.getY(p);
            if (id == stickPointer) {
                float dx = x - stickCx, dy = y - stickCy;
                float len = (float) Math.hypot(dx, dy);
                if (len > stickR) { dx = dx / len * stickR; dy = dy / len * stickR; }
                stickX = dx / stickR; stickY = dy / stickR;
            } else {
                for (int i = 0; i < owner.length; i++) {
                    boolean inside = rects[i].contains((int) x, (int) y);
                    if (owner[i] == id && !inside) owner[i] = -1;
                    else if (owner[i] < 0 && inside && action == MotionEvent.ACTION_MOVE) owner[i] = id;
                }
            }
        }
        if (stickPointer < 0) { stickX = 0; stickY = 0; }
        publish();
        invalidate();
        return true;
    }

    private void publish() {
        int buttons = 0;
        for (int i = 0; i <= RIGHT; i++) if (owner[i] >= 0) buttons |= 1 << i;
        int lx = (int) (stickX * 32767), ly = (int) (stickY * 32767);
        if (buttons != lastButtons || lx != lastLx || ly != lastLy) {
            lastButtons = buttons; lastLx = lx; lastLy = ly;
            nativePad(buttons, lx, ly);
        }
        boolean menu = owner[MENU] >= 0;
        if (menu != menuDown) {
            menuDown = menu;
            if (menu) SDLActivity.onNativeKeyDown(KeyEvent.KEYCODE_ESCAPE);
            else SDLActivity.onNativeKeyUp(KeyEvent.KEYCODE_ESCAPE);
        }
    }
}
