package com.the3rdbirthday.recomp;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * First screen. Copies the runtime's data files out of the APK, imports the game library that
 * Termux built from your disc image (shared folder /sdcard/The3rdBirthday), checks that it
 * belongs to this app version, and starts the game.
 */
public class SetupActivity extends Activity {

    static final String SHARED_DIR = "The3rdBirthday";
    static final String[] GAME_FILES = { "libgame.so", "image.bin", "launch.cfg", "init.trace", "game_build.txt" };

    private TextView log;
    private Button start;
    private File home;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        home = getFilesDir();
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(48, 48, 48, 48);
        TextView title = new TextView(this);
        title.setText("The 3rd Birthday");
        title.setTextSize(24);
        root.addView(title);
        log = new TextView(this);
        log.setTextSize(15);
        log.setGravity(Gravity.START);
        ScrollView sv = new ScrollView(this);
        sv.addView(log);
        root.addView(sv, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        start = new Button(this);
        start.setText("Start game");
        start.setEnabled(false);
        start.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { launch(); }
        });
        root.addView(start);
        Button again = new Button(this);
        again.setText("Check game files again");
        again.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { check(); }
        });
        root.addView(again);
        setContentView(root);
        check();
    }

    private void say(final String s) {
        runOnUiThread(new Runnable() { @Override public void run() { log.append(s + "\n"); } });
    }

    private boolean hasStoragePermission() {
        return Build.VERSION.SDK_INT < 23
                || checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    private void check() {
        log.setText("");
        start.setEnabled(false);
        if (!hasStoragePermission()) {
            say("Allow access to files: the game needs to read your disc image and the library built by Termux.");
            requestPermissions(new String[] { Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE }, 1);
            return;
        }
        new Thread(new Runnable() { @Override public void run() { doCheck(); } }).start();
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        if (hasStoragePermission()) check();
        else say("Without file access nothing can be loaded. Grant it in Settings > Apps > The 3rd Birthday > Permissions.");
    }

    private void doCheck() {
        try {
            say("Version " + versionName() + ", kit " + readAsset("kit_id.txt"));
            copyRuntimeData();
            File shared = new File(Environment.getExternalStorageDirectory(), SHARED_DIR);
            File sharedLib = new File(shared, "libgame.so");
            if (!sharedLib.exists() && !new File(home, "libgame.so").exists()) {
                say("\nThe game is not prepared yet.\nIn Termux run:  bash prepare.sh /path/to/your.iso\n"
                        + "(see android/README.md). Files are expected in " + shared.getPath());
                return;
            }
            if (sharedLib.exists()) importGame(shared);
            File info = new File(home, "game_build.txt");
            String kit = readKeyValue(info, "kit");
            String want = readAsset("kit_id.txt");
            if (kit == null || !kit.equals(want)) {
                say("\nThe game library was built for kit '" + kit + "' but this app is kit '" + want + "'.\n"
                        + "Run prepare.sh in Termux again (with the kit zip from the same build).");
                return;
            }
            String iso = readKeyValue(new File(home, "launch.cfg"), "iso");
            if (iso == null || !new File(iso).canRead()) {
                say("\nThe disc image was not found" + (iso != null ? ": " + iso : "") + ".\nRun prepare.sh again with the right path.");
                return;
            }
            writeDefaultGraphicsCfg();
            say("\nReady. Disc image: " + iso);
            runOnUiThread(new Runnable() { @Override public void run() { start.setEnabled(true); } });
        } catch (Exception e) {
            say("\nError: " + e);
        }
    }

    private String versionName() {
        try { return getPackageManager().getPackageInfo(getPackageName(), 0).versionName; }
        catch (Exception e) { return "?"; }
    }

    // ---- data files from the APK ---------------------------------------------------------
    private void copyRuntimeData() throws IOException {
        String stamp = versionName() + "/" + readAsset("kit_id.txt");
        File mark = new File(home, ".assets_stamp");
        if (mark.exists() && stamp.equals(readFirstLine(mark)) && new File(home, "font/ltn0.pgf").exists()) return;
        say("Unpacking runtime data...");
        copyAssetDir("font", new File(home, "font"));
        copyAssetDir("assets", new File(home, "assets"));
        FileOutputStream o = new FileOutputStream(mark);
        o.write(stamp.getBytes("UTF-8"));
        o.close();
    }

    private void copyAssetDir(String path, File dst) throws IOException {
        String[] list = getAssets().list(path);
        if (list == null || list.length == 0) { copyAsset(path, dst); return; }
        dst.mkdirs();
        for (String n : list) copyAssetDir(path + "/" + n, new File(dst, n));
    }

    private void copyAsset(String path, File dst) throws IOException {
        InputStream in = getAssets().open(path);
        try { copyStream(in, dst); } finally { in.close(); }
    }

    private String readAsset(String name) {
        try {
            InputStream in = getAssets().open(name);
            try {
                byte[] buf = new byte[256];
                int n = in.read(buf);
                return n > 0 ? new String(buf, 0, n, "UTF-8").trim() : "";
            } finally { in.close(); }
        } catch (IOException e) { return "dev"; }
    }

    // ---- game files from Termux ------------------------------------------------------------
    private void importGame(File shared) throws IOException {
        String a = readFirstFile(new File(shared, "game_build.txt"));
        String b = readFirstFile(new File(home, "game_build.txt"));
        if (a != null && a.equals(b) && new File(home, "libgame.so").exists()
                && new File(shared, "libgame.so").length() == new File(home, "libgame.so").length()) {
            // same build: only refresh launch.cfg (the disc path may have changed)
            copyIfPresent(new File(shared, "launch.cfg"), new File(home, "launch.cfg"));
            return;
        }
        say("Importing the game from " + shared.getPath() + " ...");
        for (String f : GAME_FILES) copyIfPresent(new File(shared, f), new File(home, f));
        new File(home, "libgame.so").setReadOnly();
        say("Imported.");
    }

    private void copyIfPresent(File src, File dst) throws IOException {
        if (!src.exists()) return;
        if (dst.exists()) dst.delete();
        FileInputStream in = new FileInputStream(src);
        try { copyStream(in, dst); } finally { in.close(); }
    }

    private static void copyStream(InputStream in, File dst) throws IOException {
        File parent = dst.getParentFile();
        if (parent != null) parent.mkdirs();
        OutputStream out = new FileOutputStream(dst);
        try {
            byte[] buf = new byte[1 << 16];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        } finally { out.close(); }
    }

    private void writeDefaultGraphicsCfg() throws IOException {
        File cfg = new File(home, "graphics.cfg");
        if (cfg.exists()) return;
        // phone-friendly first-run defaults (the Esc menu can change them): PSP resolution,
        // no frame interpolation, no glow, no texture packs, no update check
        FileOutputStream o = new FileOutputStream(cfg);
        o.write("render_scale=1\nframe_interpolation=0\nglow=0\ntexture_packs=0\nupdate_check=0\n".getBytes("UTF-8"));
        o.close();
    }

    private static String readFirstLine(File f) throws IOException {
        BufferedReader r = new BufferedReader(new FileReader(f));
        try { return r.readLine(); } finally { r.close(); }
    }

    private static String readFirstFile(File f) {
        try { return f.exists() ? readFirstLine(f) + "|" + f.length() : null; } catch (IOException e) { return null; }
    }

    private static String readKeyValue(File f, String key) {
        try {
            BufferedReader r = new BufferedReader(new FileReader(f));
            try {
                String line;
                while ((line = r.readLine()) != null)
                    if (line.startsWith(key + "=")) return line.substring(key.length() + 1).trim();
            } finally { r.close(); }
        } catch (IOException e) { /* missing file: null */ }
        return null;
    }

    private void launch() {
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }
}
