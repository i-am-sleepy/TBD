package com.the3rdbirthday.recomp;

import android.os.Bundle;
import android.system.ErrnoException;
import android.system.Os;
import android.view.WindowManager;

import org.libsdl.app.SDLActivity;

import java.io.File;

/** The game screen: SDL3 owns the window; the native runtime (libmain.so) is SDL_main. */
public class MainActivity extends SDLActivity {

    @Override
    protected String[] getLibraries() {
        return new String[] { "SDL3", "main" };
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Everything the runtime reads and writes (saves, graphics.cfg, libgame.so, image.bin,
        // font/, assets/) lives in the app's private folder; the shim's GetModuleFileName and
        // LoadLibrary use SR_HOME. Must be set before SDLActivity starts the native thread.
        File home = getFilesDir();
        try {
            Os.setenv("SR_HOME", home.getAbsolutePath(), true);
        } catch (ErrnoException e) {
            // cannot happen for a valid name; the runtime then falls back to the working directory
        }
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (mLayout != null) {
            mLayout.addView(new TouchOverlay(this));
        }
    }
}
